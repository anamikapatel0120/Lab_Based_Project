#include "G4RunManager.hh"
#include "G4UImanager.hh"
#include "QGSP_BIC.hh"

#include "DetectorConstruction.hh"
#include "ActionInitialization.hh"

int main()
{
    G4RunManager* runManager = new G4RunManager;

    // Detector geometry
    runManager->SetUserInitialization(new DetectorConstruction());

    // Physics list
    runManager->SetUserInitialization(new QGSP_BIC);

    // All user actions are registered here
    runManager->SetUserInitialization(new ActionInitialization());

    // Initialize Geant4
    runManager->Initialize();

    // Execute macro file
    G4UImanager::GetUIpointer()->ApplyCommand("/control/execute run.mac");

    delete runManager;
    return 0;
}