// #ifndef DetectorConstruction_h
// #define DetectorConstruction_h

// #include "G4VUserDetectorConstruction.hh"

// class DetectorConstruction : public G4VUserDetectorConstruction
// {
// public:
//     DetectorConstruction();
//     virtual ~DetectorConstruction();

//     virtual G4VPhysicalVolume* Construct();
// };

// #endif




#ifndef DetectorConstruction_h
#define DetectorConstruction_h

#include "G4VUserDetectorConstruction.hh"

class G4LogicalVolume;

class DetectorConstruction : public G4VUserDetectorConstruction
{
public:
    DetectorConstruction();
    virtual ~DetectorConstruction();

    virtual G4VPhysicalVolume* Construct();

    // Return detector logical volume
    G4LogicalVolume* GetDetectorVolume() const;

private:
    G4LogicalVolume* fDetectorVolume;
};

#endif