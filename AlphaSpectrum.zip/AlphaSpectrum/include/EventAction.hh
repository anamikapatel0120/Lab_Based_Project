#ifndef EventAction_h
#define EventAction_h

#include "G4UserEventAction.hh"
#include "globals.hh"     // IMPORTANT for G4double

class RunAction;

class EventAction : public G4UserEventAction
{
public:
    EventAction(RunAction*);
    virtual ~EventAction();

    virtual void BeginOfEventAction(const G4Event*);
    virtual void EndOfEventAction(const G4Event*);

    void AddEdep(G4double edep);

private:
    RunAction* fRunAction;
    G4double   fEdep;
};

#endif