// #include "ActionInitialization.hh"

// #include "PrimaryGeneratorAction.hh"
// #include "RunAction.hh"
// #include "EventAction.hh"

// ActionInitialization::ActionInitialization()
//  : G4VUserActionInitialization()
// {
// }

// ActionInitialization::~ActionInitialization()
// {
// }

// void ActionInitialization::BuildForMaster() const
// {
//     SetUserAction(new RunAction);
// }

// void ActionInitialization::Build() const
// {
//     // Primary generator
//     SetUserAction(new PrimaryGeneratorAction);

//     // Run action
//     RunAction* runAction = new RunAction;
//     SetUserAction(runAction);

//     // Event action
//     EventAction* eventAction = new EventAction(runAction);
//     SetUserAction(eventAction);
// }






// ActionInitialization.cc

#include "ActionInitialization.hh"

#include "PrimaryGeneratorAction.hh"
#include "RunAction.hh"
#include "EventAction.hh"
#include "SteppingAction.hh"
#include "DetectorConstruction.hh"

#include "G4RunManager.hh"

ActionInitialization::ActionInitialization()
 : G4VUserActionInitialization()
{
}

ActionInitialization::~ActionInitialization()
{
}

void ActionInitialization::BuildForMaster() const
{
    SetUserAction(new RunAction);
}

void ActionInitialization::Build() const
{
    // Primary source
    SetUserAction(new PrimaryGeneratorAction);

    // Run action
    RunAction* runAction = new RunAction;
    SetUserAction(runAction);

    // Event action
    EventAction* eventAction = new EventAction(runAction);
    SetUserAction(eventAction);

    // Get detector construction
    const DetectorConstruction* detector =
        static_cast<const DetectorConstruction*>
        (G4RunManager::GetRunManager()->GetUserDetectorConstruction());

    // Stepping action for detector scoring
    SetUserAction(new SteppingAction(eventAction, detector));
}