// #include "DetectorConstruction.hh"

// #include "G4NistManager.hh"
// #include "G4Box.hh"
// #include "G4LogicalVolume.hh"
// #include "G4PVPlacement.hh"
// #include "G4SystemOfUnits.hh"

// DetectorConstruction::DetectorConstruction(){}
// DetectorConstruction::~DetectorConstruction(){}

// G4VPhysicalVolume* DetectorConstruction::Construct()
// {
//     G4NistManager* nist = G4NistManager::Instance();

//     G4Material* air = nist->FindOrBuildMaterial("G4_AIR");

//     // World
//     G4Box* solidWorld =
//         new G4Box("World",50*cm,50*cm,50*cm);

//     G4LogicalVolume* logicWorld =
//         new G4LogicalVolume(solidWorld,air,"World");

//     G4VPhysicalVolume* physWorld =
//         new G4PVPlacement(0,G4ThreeVector(),
//         logicWorld,"World",0,false,0,true);

//     return physWorld;
// }
#include "DetectorConstruction.hh"

#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"

DetectorConstruction::DetectorConstruction()
{
    fDetectorVolume = nullptr;
}

DetectorConstruction::~DetectorConstruction(){}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
    G4NistManager* nist = G4NistManager::Instance();

    // Materials
    G4Material* air = nist->FindOrBuildMaterial("G4_AIR");
    G4Material* silicon = nist->FindOrBuildMaterial("G4_Si");

    // -------------------------
    // World Volume
    // -------------------------
    G4Box* solidWorld =
        new G4Box("World", 50*cm, 50*cm, 50*cm);

    G4LogicalVolume* logicWorld =
        new G4LogicalVolume(
            solidWorld,
            air,
            "World"
        );

    G4VPhysicalVolume* physWorld =
        new G4PVPlacement(
            0,
            G4ThreeVector(),
            logicWorld,
            "World",
            0,
            false,
            0,
            true
        );

    // -------------------------
    // Silicon Detector
    // moved closer: z = 2 cm
    // -------------------------
    G4Box* solidDetector =
        new G4Box("Detector", 2*cm, 2*cm, 0.5*mm);

    fDetectorVolume =
        new G4LogicalVolume(
            solidDetector,
            silicon,
            "Detector"
        );

    new G4PVPlacement(
        0,
        G4ThreeVector(0,0,0.5*cm),   // updated from 5 cm to 2 cm
        fDetectorVolume,
        "Detector",
        logicWorld,
        false,
        0,
        true
    );

    return physWorld;
}

// -------------------------
// Return detector volume
// -------------------------
G4LogicalVolume* DetectorConstruction::GetDetectorVolume() const
{
    return fDetectorVolume;
}