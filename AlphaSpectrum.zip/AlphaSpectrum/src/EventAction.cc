// #include "EventAction.hh"
// #include "RunAction.hh"
// #include "G4Event.hh"
// #include "G4PrimaryVertex.hh"
// #include "G4PrimaryParticle.hh"
// #include "G4SystemOfUnits.hh"

// EventAction::EventAction(RunAction* run)
// {
//     fRunAction = run;
// }

// EventAction::~EventAction(){}

// void EventAction::EndOfEventAction(const G4Event* event)
// {
//     G4double E =
//     event->GetPrimaryVertex(0)
//     ->GetPrimary(0)
//     ->GetKineticEnergy()/MeV;

//     fRunAction->SaveEnergy(E);
// }


// EventAction.cc

#include "EventAction.hh"
#include "RunAction.hh"

#include "G4Event.hh"
#include "G4SystemOfUnits.hh"

EventAction::EventAction(RunAction* run)
{
    fRunAction = run;
    fEdep = 0.0;
}

EventAction::~EventAction(){}

void EventAction::BeginOfEventAction(const G4Event*)
{
    // Reset deposited energy every event
    fEdep = 0.0;
}

void EventAction::AddEdep(G4double edep)
{
    fEdep += edep;
}

void EventAction::EndOfEventAction(const G4Event*)
{
    // Save detector deposited energy in MeV
    fRunAction->SaveEnergy(fEdep / MeV);
}