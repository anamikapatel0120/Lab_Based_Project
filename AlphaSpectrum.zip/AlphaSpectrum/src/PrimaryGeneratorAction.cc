// #include "PrimaryGeneratorAction.hh"

// #include "G4ParticleTable.hh"
// #include "G4SystemOfUnits.hh"
// #include "Randomize.hh"

// PrimaryGeneratorAction::PrimaryGeneratorAction()
// {
//     fParticleGun = new G4ParticleGun(1);

//     G4ParticleDefinition* particle
//       = G4ParticleTable::GetParticleTable()
//       ->FindParticle("alpha");

//     fParticleGun->SetParticleDefinition(particle);
//     fParticleGun->SetParticlePosition(G4ThreeVector(0,0,0));
//     fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0,0,1));
// }

// PrimaryGeneratorAction::~PrimaryGeneratorAction()
// {
//     delete fParticleGun;
// }

// void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
// {
//     // Random energy between 4 and 8 MeV
//     G4double energy = (4.0 + 4.0*G4UniformRand())*MeV;

//     fParticleGun->SetParticleEnergy(energy);
//     fParticleGun->GeneratePrimaryVertex(event);
// }







#include "PrimaryGeneratorAction.hh"

#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
    fParticleGun = new G4ParticleGun(1);

    G4ParticleDefinition* particle
      = G4ParticleTable::GetParticleTable()
      ->FindParticle("alpha");

    fParticleGun->SetParticleDefinition(particle);
    fParticleGun->SetParticlePosition(G4ThreeVector(0,0,0));
    fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0,0,1));
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
    // Discrete energies: 4, 5, 6, 7, 8 MeV
    G4double energies[5] = {4.0, 5.0, 6.0, 7.0, 8.0};

    // Random index from 0 to 4
    G4int index = G4RandFlat::shootInt(5);

    G4double energy = energies[index] * MeV;

    fParticleGun->SetParticleEnergy(energy);
    fParticleGun->GeneratePrimaryVertex(event);
}