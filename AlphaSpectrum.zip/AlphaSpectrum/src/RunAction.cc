// #include "RunAction.hh"
// #include "G4Run.hh"
// #include "G4ios.hh"

// RunAction::RunAction(){}
// RunAction::~RunAction(){}

// void RunAction::BeginOfRunAction(const G4Run*)
// {
//     file.open("alpha_spectrum.txt", std::ios::out);
//     file << "Event Energy(MeV)\n";

//     G4cout << "Output file alpha_spectrum.txt opened." << G4endl;
// }

// void RunAction::EndOfRunAction(const G4Run*)
// {
//     file.close();

//     G4cout << "Simulation complete. File saved." << G4endl;
// }

// void RunAction::SaveEnergy(double E)
// {
//     file << E << "\n";
// }




// RunAction.cc

#include "RunAction.hh"

#include "G4Run.hh"
#include "G4ios.hh"

RunAction::RunAction(){}
RunAction::~RunAction(){}

void RunAction::BeginOfRunAction(const G4Run*)
{
    file.open("alpha_spectrum.txt", std::ios::out);

    // Header for detector response spectrum
    file << "Detected Energy(MeV)\n";

    G4cout << "Output file alpha_spectrum.txt opened." << G4endl;
}

void RunAction::EndOfRunAction(const G4Run*)
{
    file.close();

    G4cout << "Simulation complete. File saved." << G4endl;
}

void RunAction::SaveEnergy(double E)
{
    file << E << "\n";
}