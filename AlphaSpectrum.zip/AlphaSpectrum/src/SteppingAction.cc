// SteppingAction.cc

#include "SteppingAction.hh"

#include "EventAction.hh"
#include "DetectorConstruction.hh"

#include "G4Step.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4StepPoint.hh"

SteppingAction::SteppingAction(
    EventAction* eventAction,
    const DetectorConstruction* detector)
{
    fEventAction = eventAction;
    fDetectorVolume = detector->GetDetectorVolume();
}

SteppingAction::~SteppingAction()
{
}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
    // Current volume
    G4LogicalVolume* volume =
        step->GetPreStepPoint()
            ->GetTouchableHandle()
            ->GetVolume()
            ->GetLogicalVolume();

    // Only score inside detector
    if (volume != fDetectorVolume) return;

    // Energy deposited in this step
    G4double edep = step->GetTotalEnergyDeposit();

    // Add to event total
    fEventAction->AddEdep(edep);
}