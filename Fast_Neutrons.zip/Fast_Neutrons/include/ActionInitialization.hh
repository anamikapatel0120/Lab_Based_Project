#ifndef B1ActionInitialization_h
#define B1ActionInitialization_h 1

#include "G4VUserActionInitialization.hh"
#include "RunAction.hh"   // ✅ REQUIRED

namespace B1
{

class ActionInitialization : public G4VUserActionInitialization
{
  public:
    ActionInitialization() = default;
    ~ActionInitialization() override = default;

    void BuildForMaster() const override;
    void Build() const override;

    RunAction* GetRunAction() const { return fRunAction; }

  private:
    mutable RunAction* fRunAction = nullptr;
};

}  // namespace B1

#endif