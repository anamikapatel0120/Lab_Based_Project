#ifndef B1EventAction_h
#  define B1EventAction_h 1

#  include "G4UserEventAction.hh"
#  include "globals.hh"

namespace B1
{

class RunAction;

class EventAction : public G4UserEventAction
{
  public:
    EventAction(RunAction* runAction);
    ~EventAction() override = default;

    void BeginOfEventAction(const G4Event*) override;
    void EndOfEventAction(const G4Event*) override;

    // THIS IS CRITICAL
    // void AddCount() { fCount++; }
    void AddCount()
    {
      // if (fCount == 0) fCount = 1;
      fCount = 1;
    }

  private:
    RunAction* fRunAction = nullptr;
    G4int fCount = 0;
};

}  // namespace B1

#endif