#ifndef B1RunAction_h
#define B1RunAction_h 1

#include "G4UserRunAction.hh"
#include <fstream>

namespace B1
{

class RunAction : public G4UserRunAction
{
  public:
    RunAction();
    ~RunAction() override;

    void BeginOfRunAction(const G4Run*) override;
    void EndOfRunAction(const G4Run*) override;

    void AddCount(G4int count);

    void SetThickness(G4double t) { fThickness = t; }
    void SetNEvents(G4int n) { fNEvents = n; }

  private:
    G4int fTotalCount = 0;
    G4double fThickness = 0.0;
    G4int fNEvents = 0;

    std::ofstream fOutFile;
};

}

#endif