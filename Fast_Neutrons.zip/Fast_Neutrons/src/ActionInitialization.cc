#include "ActionInitialization.hh"

#include "EventAction.hh"
#include "PrimaryGeneratorAction.hh"
#include "RunAction.hh"
#include "SteppingAction.hh"

namespace B1
{

void ActionInitialization::BuildForMaster() const
{
  // fRunAction = new RunAction;   // store pointer
  // SetUserAction(fRunAction);
}

void ActionInitialization::Build() const
{
  // Primary generator
  SetUserAction(new PrimaryGeneratorAction);

  // RunAction
  fRunAction = new RunAction;   // store pointer
  SetUserAction(fRunAction);

  // EventAction
  auto eventAction = new EventAction(fRunAction);
  SetUserAction(eventAction);

  // SteppingAction
  SetUserAction(new SteppingAction(eventAction));
}

}