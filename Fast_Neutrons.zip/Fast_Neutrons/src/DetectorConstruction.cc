#include "DetectorConstruction.hh"

#include "G4Box.hh"
#include "G4Element.hh"
#include "G4Isotope.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4Tubs.hh"

namespace B1
{

DetectorConstruction::DetectorConstruction()
  : G4VUserDetectorConstruction(), fScoringVolume(nullptr), fThickness(0.0)
{}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  G4NistManager* nist = G4NistManager::Instance();
  G4bool checkOverlaps = true;

  // ================= WORLD =================
  auto world_mat = nist->FindOrBuildMaterial("G4_AIR");

  G4double world_size = 500 * cm;

  auto solidWorld = new G4Box("World", world_size, world_size, world_size);
  auto logicWorld = new G4LogicalVolume(solidWorld, world_mat, "World");

  auto physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", nullptr, false,
                                     0, checkOverlaps);

  // G4Material* matFoil = G4Material::GetMaterial("Cl35Mat");

  // if (!matFoil)
  // {
  //   // Define Cl-35 isotope
  //   G4Isotope* Cl35 = new G4Isotope("Cl35", 17, 35, 35.0 * g / mole);

  //   // Element using only Cl-35
  //   G4Element* elCl35 = new G4Element("Chlorine35", "Cl35", 1);
  //   elCl35->AddIsotope(Cl35, 100. * perCent);

  //   // Material
  //   matFoil = new G4Material("Cl35Mat", 2.0 * g / cm3, 1);
  //   matFoil->AddElement(elCl35, 1);
  // }

  // ================= FOIL MATERIAL =================

  // Use natural chlorine from NIST
  // G4Material* matFoil = G4NistManager::Instance()->FindOrBuildMaterial("G4_Cl");

  // ================= FOIL MATERIAL =================

  G4Material* matFoil = G4Material::GetMaterial("DenseCl");

  if (!matFoil)
  {
    matFoil = new G4Material("DenseCl", 5.0 * g / cm3, 1);
    matFoil->AddMaterial(nist->FindOrBuildMaterial("G4_Cl"), 1.0);
  }
  // ================= FOIL =================

  G4double radius = 5 * cm;
  G4double safeThickness = (fThickness > 0) ? fThickness : 1e-6 * mm;

  auto solidFoil = new G4Tubs("Foil", 0, radius, safeThickness / 2, 0, 360 * deg);
  auto logicFoil = new G4LogicalVolume(solidFoil, matFoil, "Foil");

  // Keep front face fixed
  G4double foilFrontZ = 2 * mm;
  G4double foilCenterZ = foilFrontZ + safeThickness / 2;

  new G4PVPlacement(nullptr, G4ThreeVector(0, 0, foilCenterZ), logicFoil, "Foil", logicWorld, false,
                    0, checkOverlaps);

  // ================= DETECTOR =================
  // Air detector → counts neutrons passing through

  auto detectorMat = nist->FindOrBuildMaterial("G4_AIR");

  G4double detRadius = 5 * cm;
  G4double detLength = 1 * cm;

  auto solidDetector = new G4Tubs("Detector", 0, detRadius, detLength / 2, 0, 360 * deg);
  auto logicDetector = new G4LogicalVolume(solidDetector, detectorMat, "Detector");

  // Place detector just after foil
  G4double detectorZ = foilCenterZ + safeThickness / 2 + detLength / 2 + 1 * mm;

  new G4PVPlacement(nullptr, G4ThreeVector(0, 0, detectorZ), logicDetector, "Detector", logicWorld,
                    false, 0, checkOverlaps);

  // Scoring volume
  fScoringVolume = logicDetector;

  return physWorld;
}

}  // namespace B1