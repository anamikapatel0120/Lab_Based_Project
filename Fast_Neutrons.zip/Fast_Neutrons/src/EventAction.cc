#include "EventAction.hh"

#include "G4Event.hh"
#include "G4ios.hh"

#include "RunAction.hh"

namespace B1
{

EventAction::EventAction(RunAction* runAction)
 : fRunAction(runAction)
{}

void EventAction::BeginOfEventAction(const G4Event*)
{
  // Reset count for each event
  fCount = 0;
}

void EventAction::EndOfEventAction(const G4Event* event)
{
  G4int eventID = event->GetEventID();

  // Send count (0 or 1) to RunAction
  fRunAction->AddCount(fCount);

  // Debug print (first few events)
  if (eventID < 5)
  {
    G4cout << "Event " << eventID
           << " Count: " << fCount
           << G4endl;
  }
}

}  // namespace B1