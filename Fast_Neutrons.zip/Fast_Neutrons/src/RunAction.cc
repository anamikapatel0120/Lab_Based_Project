#include "RunAction.hh"

#include "G4Run.hh"
#include "G4SystemOfUnits.hh"
#include "G4ios.hh"

#include <cmath>

namespace B1
{

RunAction::RunAction() {}

RunAction::~RunAction()
{
  if (fOutFile.is_open())
    fOutFile.close();
}

void RunAction::BeginOfRunAction(const G4Run*)
{
  // Reset counts
  fTotalCount = 0;

  // Open file once
  if (!fOutFile.is_open())
  {
    fOutFile.open("results.txt", std::ios::out);
    fOutFile << "Thickness(mm)\tCounts\tTransmission\tln(T)\n";
  }
}

void RunAction::AddCount(G4int count)
{
  fTotalCount += count;
}

void RunAction::EndOfRunAction(const G4Run*)
{
  // Thickness
  G4double thickness_mm = fThickness / mm;

  // Transmission probability
  G4double T = (fNEvents > 0) ? (G4double)fTotalCount / fNEvents : 0;

  // Natural log
  G4double lnT = (T > 0) ? std::log(T) : -999;

  // Write to file
  fOutFile << thickness_mm << "\t"
           << fTotalCount << "\t"
           << T << "\t"
           << lnT << "\n";

  // Console output
  G4cout << "Thickness: " << thickness_mm << " mm "
         << "Counts: " << fTotalCount
         << " Transmission: " << T
         << G4endl;

  fOutFile.flush();
}

}  // namespace B1