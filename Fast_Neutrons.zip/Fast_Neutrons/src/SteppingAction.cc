#include "SteppingAction.hh"

#include "G4Neutron.hh"
#include "G4LogicalVolume.hh"
#include "G4RunManager.hh"
#include "G4Step.hh"
#include "G4Track.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"

namespace B1
{

SteppingAction::SteppingAction(EventAction* eventAction)
  : fEventAction(eventAction), fScoringVolume(nullptr)
{}

void SteppingAction::UserSteppingAction(const G4Step* step)
{

  const auto detConstruction = static_cast<const DetectorConstruction*>(
    G4RunManager::GetRunManager()->GetUserDetectorConstruction());

  auto scoringVolume = detConstruction->GetScoringVolume();

  // Get track
  auto track = step->GetTrack();

  if (track->GetDefinition() != G4Neutron::Definition()) return;

  // Get step points
  auto prePoint = step->GetPreStepPoint();
  auto postPoint = step->GetPostStepPoint();

  if (!prePoint || !postPoint) return;

  // Get volumes
  auto preVol = prePoint->GetTouchableHandle()->GetVolume();
  auto postVol = postPoint->GetTouchableHandle()->GetVolume();

  if (!preVol || !postVol) return;

  auto preLV = preVol->GetLogicalVolume();
  auto postLV = postVol->GetLogicalVolume();

  if (postPoint->GetStepStatus() == fGeomBoundary && postLV == scoringVolume)
  {
    fEventAction->AddCount();

    // kill track → avoid double counting
    track->SetTrackStatus(fStopAndKill);
  }
}

}  // namespace B1