#include "G4RunManagerFactory.hh"
#include "G4SystemOfUnits.hh"
#include "G4UImanager.hh"

#include "ActionInitialization.hh"
#include "DetectorConstruction.hh"

#include "CLHEP/Random/Random.h"
#include "FTFP_BERT_HP.hh"

#include <ctime>

using namespace B1;

int main(int argc, char** argv)
{
  // Random seed
  CLHEP::HepRandom::setTheSeed(time(0));

  auto runManager = G4RunManagerFactory::CreateRunManager(G4RunManagerType::Serial);

  auto detector = new DetectorConstruction();
  runManager->SetUserInitialization(detector);

  auto physicsList = new FTFP_BERT_HP();
  runManager->SetUserInitialization(physicsList);

  auto actionInit = new ActionInitialization();
  runManager->SetUserInitialization(actionInit);

  runManager->Initialize();

  // Get RunAction
  // auto runAction = actionInit->GetRunAction();
  auto runAction =
    const_cast<RunAction*>(static_cast<const RunAction*>(runManager->GetUserRunAction()));

  if (!runAction)
  {
    G4cerr << "RunAction not initialized!" << G4endl;
    return 1;
  }

  G4int nEvents = 100000;

  // Thickness loop (optimized)
  for (int i = 50; i <= 100; i++)
  {
    double t = i * 10;
    G4cout << "\n===== Running for thickness = " << t << " mm =====\n";

    detector->SetThickness(t * mm);
    runAction->SetThickness(t * mm);
    runAction->SetNEvents(nEvents);

    runManager->GeometryHasBeenModified();
    runManager->ReinitializeGeometry(true);
    runManager->Initialize();

    runManager->BeamOn(nEvents);
  }

  delete runManager;
  return 0;
}