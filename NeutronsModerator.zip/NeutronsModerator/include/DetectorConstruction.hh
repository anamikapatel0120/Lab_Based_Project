/// \file DetectorConstruction.hh

#ifndef B1DetectorConstruction_h
#  define B1DetectorConstruction_h 1

#  include "G4VUserDetectorConstruction.hh"

class G4VPhysicalVolume;
class G4LogicalVolume;

namespace B1
{

class DetectorConstruction : public G4VUserDetectorConstruction
{
  public:
    DetectorConstruction();
    ~DetectorConstruction() override = default;

    G4VPhysicalVolume* Construct() override;

    G4LogicalVolume* GetScoringVolume() const { return fScoringVolume; }

    // IMPORTANT: thickness control
    void SetThickness(G4double val) { fThickness = val; }

  private:
    G4LogicalVolume* fScoringVolume = nullptr;  // detector

    // CRITICAL VARIABLE
    G4double fThickness = 0.0;
};

}  // namespace B1

#endif