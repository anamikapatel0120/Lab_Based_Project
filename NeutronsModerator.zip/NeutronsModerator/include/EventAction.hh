#ifndef B1EventAction_h
#  define B1EventAction_h 1

#  include "G4UserEventAction.hh"
#  include "globals.hh"

namespace B1
{

class RunAction;

class EventAction : public G4UserEventAction
{
  public:
    EventAction(RunAction* runAction);
    ~EventAction() override = default;

    void BeginOfEventAction(const G4Event*) override;
    void EndOfEventAction(const G4Event*) override;

    // Count neutron transmission (0 or 1 per event)
    void AddCount() { fCount = 1; }

    //
    void AddEnergy(G4double energy) { fEnergy = energy; }

    void AddThermal()
    {
      fThermalCount = 1;  // same logic as AddCount (one per event)
    }

  private:
    RunAction* fRunAction = nullptr;

    G4int fCount = 0;
    G4double fEnergy = 0.0;
    G4int fThermalCount = 0;
};

}  // namespace B1

#endif