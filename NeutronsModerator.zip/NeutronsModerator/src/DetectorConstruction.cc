#include "DetectorConstruction.hh"

#include "G4Box.hh"
#include "G4Element.hh"
#include "G4Isotope.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4Sphere.hh"
#include "G4SystemOfUnits.hh"

namespace B1
{

DetectorConstruction::DetectorConstruction()
  : G4VUserDetectorConstruction(), fScoringVolume(nullptr), fThickness(0.0)
{}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  G4NistManager* nist = G4NistManager::Instance();
  G4bool checkOverlaps = true;

  // ================= WORLD =================
  auto world_mat = nist->FindOrBuildMaterial("G4_AIR");

  G4double world_size = 500 * cm;

  auto solidWorld = new G4Box("World", world_size, world_size, world_size);
  auto logicWorld = new G4LogicalVolume(solidWorld, world_mat, "World");

  auto physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", nullptr, false,
                                     0, checkOverlaps);

  // ================= CHOOSE ONE MATERIAL ONLY =================

  // -------- HDPE --------
  // G4Material* matFoil = G4Material::GetMaterial("HDPE");

  // if (!matFoil)
  // {
  //   matFoil = nist->FindOrBuildMaterial("G4_POLYETHYLENE");
  // }

  // -------- WATER (H2O) --------
  // G4Material* matFoil = G4Material::GetMaterial("Water");

  // if (!matFoil)
  // {
  //   matFoil = nist->FindOrBuildMaterial("G4_WATER");
  // }

  // -------- PARAFFIN --------
  G4Material* matFoil = G4Material::GetMaterial("Paraffin");

  if (!matFoil)
  {
    G4Element* elC = nist->FindOrBuildElement("C");
    G4Element* elH = nist->FindOrBuildElement("H");

    matFoil = new G4Material("Paraffin", 0.93 * g / cm3, 2);
    matFoil->AddElement(elC, 25);
    matFoil->AddElement(elH, 52);
  }

  // -------- HEAVY WATER (D2O) --------
  // G4Material* matFoil = G4Material::GetMaterial("HeavyWater");

  // if (!matFoil)
  // {
  //   G4Isotope* H2 = new G4Isotope("H2", 1, 2, 2.014 * g / mole);

  //   G4Element* elD = new G4Element("Deuterium", "D", 1);
  //   elD->AddIsotope(H2, 100. * perCent);

  //   G4Element* elO = nist->FindOrBuildElement("O");

  //   matFoil = new G4Material("HeavyWater", 1.105 * g / cm3, 2);
  //   matFoil->AddElement(elD, 2);
  //   matFoil->AddElement(elO, 1);
  // }

  // ================= MODERATOR (SPHERE) =================

  // G4double safeThickness = (fThickness > 0) ? fThickness : 1e-6 * mm;

  G4double innerR = 1 * mm;
  G4double safeThickness = (fThickness > innerR) ? fThickness : innerR + 1e-6 * mm;

  auto solidModerator =
    new G4Sphere("Moderator", innerR, safeThickness, 0, 360 * deg, 0, 180 * deg);

  auto logicModerator = new G4LogicalVolume(solidModerator, matFoil, "Moderator");

  new G4PVPlacement(nullptr, G4ThreeVector(), logicModerator, "Moderator", logicWorld, false, 0,
                    checkOverlaps);

  // ================= DETECTOR (OUTSIDE MODERATOR) =================

  // place detector OUTSIDE moderator → no overlap
  G4double detInnerR = safeThickness + 1 * mm;  // small gap
  G4double detOuterR = detInnerR + 5 * cm;  // detector thickness

  auto solidDetector = new G4Sphere("Detector", detInnerR, detOuterR, 0, 360 * deg, 0, 180 * deg);

  auto logicDetector = new G4LogicalVolume(solidDetector, world_mat, "Detector");

  // IMPORTANT: place in WORLD (not moderator)
  new G4PVPlacement(nullptr, G4ThreeVector(), logicDetector, "Detector", logicWorld, false, 0,
                    checkOverlaps);

  // Scoring volume
  fScoringVolume = logicDetector;

  return physWorld;
}

}  // namespace B1