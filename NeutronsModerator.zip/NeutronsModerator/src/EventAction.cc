#include "EventAction.hh"

#include "G4Event.hh"
#include "G4ios.hh"

#include "RunAction.hh"
#include "G4SystemOfUnits.hh"

namespace B1
{

EventAction::EventAction(RunAction* runAction)
 : fRunAction(runAction)
{}

void EventAction::BeginOfEventAction(const G4Event*)
{
  // Reset per event
  fCount = 0;
  fEnergy = 0.0; 
  fThermalCount = 0; 
}

void EventAction::EndOfEventAction(const G4Event* event)
{
  G4int eventID = event->GetEventID();

  // Send data to RunAction
  fRunAction->AddCount(fCount);
  fRunAction->AddEnergy(fEnergy); 
  fRunAction->AddThermal(fThermalCount);  

  // Debug print (first few events)
  if (eventID < 5)
  {
    G4cout << "Event " << eventID
           << " Count: " << fCount
           << " Energy: " << fEnergy / MeV << " MeV"
           << " Thermal: " << fThermalCount
           << G4endl;
  }
}

}  // namespace B1