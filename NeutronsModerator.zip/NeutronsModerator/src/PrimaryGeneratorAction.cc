#include "PrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4Neutron.hh"
#include "G4ParticleGun.hh"
#include "G4SystemOfUnits.hh"
#include "G4ThreeVector.hh"
#include "Randomize.hh"   
#include <cmath>
namespace B1
{

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
  fParticleGun = new G4ParticleGun(1);

  fParticleGun->SetParticleDefinition(G4Neutron::Definition());

  fParticleGun->SetParticleEnergy(15 * MeV);  

  fParticleGun->SetParticlePosition(G4ThreeVector(0., 0., 0.));

}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{

  G4double costheta = 2 * G4UniformRand() - 1;
  G4double sintheta = std::sqrt(1 - costheta * costheta);
  G4double phi = 2 * CLHEP::pi * G4UniformRand();

  G4ThreeVector direction(
    sintheta * std::cos(phi),
    sintheta * std::sin(phi),
    costheta
  );

  fParticleGun->SetParticleMomentumDirection(direction);

  fParticleGun->GeneratePrimaryVertex(event);
}

}  // namespace B1