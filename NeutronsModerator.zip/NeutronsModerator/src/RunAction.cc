#include "RunAction.hh"

#include "G4Run.hh"
#include "G4SystemOfUnits.hh"
#include "G4ios.hh"

#include <cmath>

namespace B1
{

RunAction::RunAction() {}

RunAction::~RunAction()
{
  if (fOutFile.is_open()) fOutFile.close();
}

void RunAction::BeginOfRunAction(const G4Run*)
{
  // Reset
  fTotalCount = 0;
  fTotalEnergy = 0.0;
  fTotalThermal = 0;

  // Open file once
  if (!fOutFile.is_open())
  {
    fOutFile.open("results.txt", std::ios::out);

    //  UPDATED HEADER
    fOutFile << "Thickness(mm)\tCounts\tTransmission\tAvgEnergy(MeV)\tThermalFraction\tln(T)\n";
  }
}

// Count accumulation
void RunAction::AddCount(G4int count)
{
  fTotalCount += count;
}

// Energy accumulation
void RunAction::AddEnergy(G4double energy)
{
  fTotalEnergy += energy;
}

void RunAction::EndOfRunAction(const G4Run*)
{
  // Thickness
  G4double thickness_mm = fThickness / mm;

  // Transmission
  G4double T = (fNEvents > 0) ? (G4double)fTotalCount / fNEvents : 0;

  // Average energy
  G4double avgEnergy = (fTotalCount > 0) ? fTotalEnergy / fTotalCount : 0;

  // ln(T)
  G4double lnT = (T > 0) ? std::log(T) : -999;

  G4double thermalFraction = (fTotalCount > 0) ? (G4double)fTotalThermal / fTotalCount : 0;

  // Write to file
  fOutFile << thickness_mm << "\t" << fTotalCount << "\t" << T << "\t" << avgEnergy / MeV << "\t"
           << thermalFraction << "\t" << lnT << "\n";
  // fOutFile << "Thickness(mm)\tCounts\tTransmission\tAvgEnergy(MeV)\tThermalFraction\tln(T)\n";

  // Console output
  G4cout << "Thickness: " << thickness_mm << " mm "
         << "Counts: " << fTotalCount << " Transmission: " << T << " AvgEnergy: " << avgEnergy / MeV
         << " MeV"
         << " ThermalFraction: " << thermalFraction << G4endl;

  fOutFile.flush();
}

}  // namespace B1