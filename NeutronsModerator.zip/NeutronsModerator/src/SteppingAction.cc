#include "SteppingAction.hh"

#include "G4LogicalVolume.hh"
#include "G4Neutron.hh"
#include "G4RunManager.hh"
#include "G4Step.hh"
#include "G4SystemOfUnits.hh"
#include "G4Track.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"

namespace B1
{

SteppingAction::SteppingAction(EventAction* eventAction)
  : fEventAction(eventAction), fScoringVolume(nullptr)
{}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
  const auto detConstruction = static_cast<const DetectorConstruction*>(
    G4RunManager::GetRunManager()->GetUserDetectorConstruction());

  fScoringVolume = detConstruction->GetScoringVolume();

  // Get track
  auto track = step->GetTrack();

  // Only consider neutrons
  if (track->GetDefinition() != G4Neutron::Definition()) return;

  // Get step points
  auto prePoint = step->GetPreStepPoint();
  auto postPoint = step->GetPostStepPoint();

  if (!prePoint || !postPoint) return;

  // Get volumes
  auto preVol = prePoint->GetTouchableHandle()->GetVolume();
  auto postVol = postPoint->GetTouchableHandle()->GetVolume();

  if (!preVol || !postVol) return;

  auto preLV = preVol->GetLogicalVolume();
  auto postLV = postVol->GetLogicalVolume();

  // DETECTOR
  if (postPoint->GetStepStatus() == fGeomBoundary && preLV != fScoringVolume
      && postLV == fScoringVolume)
  {
    G4double energy = postPoint->GetKineticEnergy();

    // Count all neutrons reaching detector
    fEventAction->AddCount();
    fEventAction->AddEnergy(energy);

    // (thermal check at detector)
    if (energy <= 0.025 * eV)
    {
      fEventAction->AddThermal();
    }

    track->SetTrackStatus(fStopAndKill);
  }
}

}  // namespace B1