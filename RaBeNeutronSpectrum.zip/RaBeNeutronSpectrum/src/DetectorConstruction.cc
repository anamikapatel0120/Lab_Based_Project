#include "DetectorConstruction.hh"

#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4Sphere.hh"
#include "G4SystemOfUnits.hh"

DetectorConstruction::DetectorConstruction() {}
DetectorConstruction::~DetectorConstruction() {}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  G4NistManager* nist = G4NistManager::Instance();

  // --------------------------
  // World (Vacuum)
  // --------------------------
  G4Material* vacuum = nist->FindOrBuildMaterial("G4_Galactic");

  G4double worldSize = 20 * cm;

  G4Sphere* solidWorld =
      new G4Sphere("World", 0, worldSize, 0, 360 * deg, 0, 180 * deg);

  G4LogicalVolume* logicWorld =
      new G4LogicalVolume(solidWorld, vacuum, "World");

  G4VPhysicalVolume* physWorld =
      new G4PVPlacement(0, {}, logicWorld, "World", 0, false, 0);

  // --------------------------
  // Source region (optional small sphere)
  // --------------------------
  G4Sphere* solidSource =
      new G4Sphere("Source", 0, 0.00001 * mm, 0, 360 * deg, 0, 180 * deg);

  G4LogicalVolume* logicSource =
      new G4LogicalVolume(solidSource, vacuum, "Source");

  new G4PVPlacement(0, {}, logicSource, "Source", logicWorld, false, 0);

  // --------------------------
  // Detector (BIG sphere)
  // --------------------------
  G4Sphere* solidDet =
      new G4Sphere("Detector", 0.00001 * mm, 10 * cm,
                   0, 360 * deg, 0, 180 * deg);

  G4LogicalVolume* logicDet =
      new G4LogicalVolume(solidDet, vacuum, "Detector");

  new G4PVPlacement(0, {}, logicDet, "Detector", logicWorld, false, 0);

  return physWorld;
}







// #include "DetectorConstruction.hh"

// #include "G4LogicalVolume.hh"
// #include "G4Material.hh"
// #include "G4NistManager.hh"
// #include "G4PVPlacement.hh"
// #include "G4Sphere.hh"
// #include "G4SystemOfUnits.hh"

// DetectorConstruction::DetectorConstruction() {}
// DetectorConstruction::~DetectorConstruction() {}

// G4VPhysicalVolume* DetectorConstruction::Construct()
// {
//   G4NistManager* nist = G4NistManager::Instance();

//   // --------------------------
//   // World (Vacuum)
//   // --------------------------
//   G4Material* vacuum = nist->FindOrBuildMaterial("G4_Galactic");

//   G4double worldSize = 40 * cm;

//   G4Sphere* solidWorld =
//       new G4Sphere("World", 0, worldSize, 0, 360 * deg, 0, 180 * deg);

//   G4LogicalVolume* logicWorld =
//       new G4LogicalVolume(solidWorld, vacuum, "World");

//   G4VPhysicalVolume* physWorld =
//       new G4PVPlacement(0, {}, logicWorld, "World", 0, false, 0);

//   // --------------------------
//   // Source region
//   // --------------------------
//   G4Sphere* solidSource =
//       new G4Sphere("Source", 0, 0.00001 * mm, 0, 360 * deg, 0, 180 * deg);

//   G4LogicalVolume* logicSource =
//       new G4LogicalVolume(solidSource, vacuum, "Source");

//   new G4PVPlacement(0, {}, logicSource, "Source", logicWorld, false, 0);

//   // --------------------------
//   // Beryllium Shell
//   // --------------------------
//   G4Material* Be = nist->FindOrBuildMaterial("G4_Be");

//   G4Sphere* solidBeShell =
//       new G4Sphere("BeShell",
//                    2.0 * mm,
//                    3.0 * mm,
//                    0, 360 * deg,
//                    0, 180 * deg);

//   G4LogicalVolume* logicBeShell =
//       new G4LogicalVolume(solidBeShell, Be, "BeShell");

//   new G4PVPlacement(0, {}, logicBeShell, "BeShell", logicWorld, false, 0);

//   // --------------------------
//   // Detector (BIG sphere)
//   // --------------------------
//   G4Sphere* solidDet =
//       new G4Sphere("Detector", 3.1 * mm, 10 * cm,
//                    0, 360 * deg, 0, 180 * deg);

//   G4LogicalVolume* logicDet =
//       new G4LogicalVolume(solidDet, vacuum, "Detector");

//   new G4PVPlacement(0, {}, logicDet, "Detector", logicWorld, false, 0);

//   return physWorld;
// }