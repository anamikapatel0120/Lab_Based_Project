#include "PhysicsList.hh"

#include "G4DecayPhysics.hh"
#include "G4EmStandardPhysics_option3.hh"
#include "G4HadronElasticPhysicsHP.hh"
#include "G4HadronPhysicsQGSP_BIC_HP.hh"
#include "G4IonPhysics.hh"
#include "G4IonElasticPhysics.hh"
#include "G4RadioactiveDecayPhysics.hh"
#include "G4StoppingPhysics.hh"
#include "G4SystemOfUnits.hh"
#include "G4EmExtraPhysics.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

PhysicsList::PhysicsList()
{
  G4int verb = 0;
  SetVerboseLevel(verb);

  RegisterPhysics(new G4HadronElasticPhysicsHP(verb));
  RegisterPhysics(new G4HadronPhysicsQGSP_BIC_HP(verb));

  RegisterPhysics(new G4IonPhysics(verb));
  RegisterPhysics(new G4IonElasticPhysics(verb));

  RegisterPhysics(new G4StoppingPhysics(verb));

  RegisterPhysics(new G4EmStandardPhysics_option3());

  RegisterPhysics(new G4DecayPhysics());

  RegisterPhysics(new G4RadioactiveDecayPhysics());
}

void PhysicsList::SetCuts()
{
  SetCutValue(0.1 * mm, "gamma");
  SetCutValue(0.1 * mm, "e-");
  SetCutValue(0.1 * mm, "e+");
  SetCutValue(0.1 * mm, "proton");
}