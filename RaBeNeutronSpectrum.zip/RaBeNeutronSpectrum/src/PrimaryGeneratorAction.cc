#include "PrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4GeneralParticleSource.hh"
#include "G4IonTable.hh"
#include "G4SystemOfUnits.hh"
#include "G4ThreeVector.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
    fGPS = new G4GeneralParticleSource();

    // Position
    auto pos = fGPS->GetCurrentSource()->GetPosDist();
    pos->SetPosDisType("Point");
    pos->SetCentreCoords(G4ThreeVector(0., 0., 0.));

    // Isotropic emission
    auto ang = fGPS->GetCurrentSource()->GetAngDist();
    ang->SetAngDistType("iso");
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
    delete fGPS;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
    G4int Z = 88;
    G4int A = 226;

    auto ion = G4IonTable::GetIonTable()->GetIon(Z, A, 0.0);
    fGPS->SetParticleDefinition(ion);

    // CRITICAL FIX: Set energy to ZERO
    fGPS->GetCurrentSource()->GetEneDist()->SetMonoEnergy(0.0 * MeV);

    fGPS->GeneratePrimaryVertex(anEvent);
}