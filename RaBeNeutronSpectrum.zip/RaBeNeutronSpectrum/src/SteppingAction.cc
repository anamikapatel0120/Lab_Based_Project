#include "SteppingAction.hh"

#include "G4Step.hh"
#include "G4Track.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4Alpha.hh"
#include "G4ios.hh"

#include <fstream>

SteppingAction::SteppingAction() {}
SteppingAction::~SteppingAction() {}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
    G4Track* track = step->GetTrack();

    // Check alpha
    if (track->GetDefinition() != G4Alpha::AlphaDefinition())
        return;

    //  Record ONLY at creation step (VERY IMPORTANT)
    if (track->GetCurrentStepNumber() != 1)
        return;

    //  Get energy
    G4double energy = track->GetKineticEnergy();

    //  Event ID
    G4int eventID =
        G4RunManager::GetRunManager()->GetCurrentEvent()->GetEventID();

    //  Write to file
    std::ofstream file("alpha_spectrum.txt", std::ios::app);
    file << "Event " << eventID
         << " : " << energy / MeV << " MeV" << std::endl;

    // Debug
    if (eventID < 5)
    {
        G4cout << "[DEBUG] Event " << eventID
               << " Alpha = " << energy / MeV << " MeV" << G4endl;
    }
}