#include "DetectorConstruction.hh"

#include "G4Box.hh"
#include "G4Element.hh"
#include "G4Isotope.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4Tubs.hh"

namespace B1
{

DetectorConstruction::DetectorConstruction()
  : G4VUserDetectorConstruction(), fScoringVolume(nullptr), fThickness(0.0)
{}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  G4NistManager* nist = G4NistManager::Instance();
  G4bool checkOverlaps = true;

  // ================= WORLD =================
  auto world_mat = nist->FindOrBuildMaterial("G4_AIR");

  G4double world_size = 500 * cm;

  auto solidWorld = new G4Box("World", world_size, world_size, world_size);
  auto logicWorld = new G4LogicalVolume(solidWorld, world_mat, "World");

  auto physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", nullptr, false,
                                     0, checkOverlaps);

  // ================= MATERIAL SELECTION =================
  // Uncomment ONLY ONE block at a time

  // ---------- Gd-157 (DEFAULT ACTIVE) ----------
  // G4Material* matFoil = G4Material::GetMaterial("Gd157Mat");

  // if (!matFoil)
  // {
  //   G4Isotope* Gd157 = new G4Isotope("Gd157", 64, 157, 156.923 * g / mole);
  //   G4Element* elGd157 = new G4Element("Gd157", "Gd157", 1);
  //   elGd157->AddIsotope(Gd157, 100. * perCent);

  //   matFoil = new G4Material("Gd157Mat", 7.9 * g / cm3, 1);
  //   matFoil->AddElement(elGd157, 1);
  // }

  // ---------- Gd-155 ----------

  // G4Material* matFoil = G4Material::GetMaterial("Gd155Mat");

  // if (!matFoil)
  // {
  //   G4Isotope* Gd155 = new G4Isotope("Gd155", 64, 155, 154.922 * g / mole);
  //   G4Element* elGd155 = new G4Element("Gd155", "Gd155", 1);
  //   elGd155->AddIsotope(Gd155, 100. * perCent);

  //   matFoil = new G4Material("Gd155Mat", 7.9 * g / cm3, 1);
  //   matFoil->AddElement(elGd155, 1);
  // }

  // ---------- Cadmium ----------
  // G4Material* matFoil = nist->FindOrBuildMaterial("G4_Cd");

  // ---------- Boron-10 ----------

  // G4Material* matFoil = G4Material::GetMaterial("B10Mat");

  // if (!matFoil)
  // {
  //   G4Isotope* B10 = new G4Isotope("B10", 5, 10, 10.0129 * g / mole);
  //   G4Element* elB10 = new G4Element("B10", "B10", 1);
  //   elB10->AddIsotope(B10, 100. * perCent);
  //   matFoil = new G4Material("B10Mat", 2.34 * g / cm3, 1);
  //   matFoil->AddElement(elB10, 1);
  // }

  // ---------- Lithium-6 ----------

  // G4Material* matFoil = G4Material::GetMaterial("Li6Mat");

  // if (!matFoil)
  // {
  //   G4Isotope* Li6 = new G4Isotope("Li6", 3, 6, 6.015 * g / mole);
  //   G4Element* elLi6 = new G4Element("Li6", "Li6", 1);
  //   elLi6->AddIsotope(Li6, 100. * perCent);
  //   matFoil = new G4Material("Li6Mat", 0.534 * g / cm3, 1);
  //   matFoil->AddElement(elLi6, 1);
  // }

  // ---------- Lithium-7 ----------
  // G4Material* matFoil = G4Material::GetMaterial("Li7Mat");
  // if (!matFoil)
  // {
  //   G4Isotope* Li7 = new G4Isotope("Li7", 3, 7, 7.016 * g / mole);
  //   G4Element* elLi7 = new G4Element("Li7", "Li7", 1);
  //   elLi7->AddIsotope(Li7, 100. * perCent);
  //   matFoil = new G4Material("Li7Mat", 0.534 * g / cm3, 1);
  //   matFoil->AddElement(elLi7, 1);
  // }

  // ---------- Helium-3 (GAS) ----------
  // G4Material* matFoil = G4Material::GetMaterial("He3Gas");
  // if (!matFoil)
  // {
  //   G4Isotope* He3 = new G4Isotope("He3", 2, 3, 3.016 * g / mole);
  //   G4Element* elHe3 = new G4Element("He3", "He3", 1);
  //   elHe3->AddIsotope(He3, 100. * perCent);
  //   matFoil = new G4Material("He3Gas", 0.000134 * g / cm3, 1);
  //   matFoil->AddElement(elHe3, 1);
  // }

  // ---------- Boron Carbide (B4C) ----------

  G4Material* matFoil = G4Material::GetMaterial("B4C");

  if (!matFoil)
  {
    // Isotope B-10 (100% enriched)
    G4Isotope* B10 = new G4Isotope("B10", 5, 10, 10.0129 * g / mole);

    G4Element* elB = new G4Element("EnrichedBoron", "B", 1);
    elB->AddIsotope(B10, 100. * perCent);

    // Carbon (natural)
    G4Element* elC = G4NistManager::Instance()->FindOrBuildElement("C");

    // Boron Carbide (B4C)
    matFoil = new G4Material("B4C", 2.52 * g / cm3, 2);

    matFoil->AddElement(elB, 4);  // 4 Boron atoms
    matFoil->AddElement(elC, 1);  // 1 Carbon atom
  }

  // ================= FOIL =================

  G4double radius = 5 * cm;
  G4double safeThickness = (fThickness > 0) ? fThickness : 1e-6 * mm;

  auto solidFoil = new G4Tubs("Foil", 0, radius, safeThickness / 2, 0, 360 * deg);
  auto logicFoil = new G4LogicalVolume(solidFoil, matFoil, "Foil");

  // Keep front face fixed
  G4double foilFrontZ = 2 * mm;
  G4double foilCenterZ = foilFrontZ + safeThickness / 2;

  new G4PVPlacement(nullptr, G4ThreeVector(0, 0, foilCenterZ), logicFoil, "Foil", logicWorld, false,
                    0, checkOverlaps);

  // ================= DETECTOR =================
  // Air detector → counts neutrons passing through

  auto detectorMat = nist->FindOrBuildMaterial("G4_AIR");

  G4double detRadius = 5 * cm;
  G4double detLength = 1 * cm;

  auto solidDetector = new G4Tubs("Detector", 0, detRadius, detLength / 2, 0, 360 * deg);
  auto logicDetector = new G4LogicalVolume(solidDetector, detectorMat, "Detector");

  // Place detector just after foil
  G4double detectorZ = foilCenterZ + safeThickness / 2 + detLength / 2 + 1 * mm;

  new G4PVPlacement(nullptr, G4ThreeVector(0, 0, detectorZ), logicDetector, "Detector", logicWorld,
                    false, 0, checkOverlaps);

  // Scoring volume
  fScoringVolume = logicDetector;

  return physWorld;
}

}  // namespace B1