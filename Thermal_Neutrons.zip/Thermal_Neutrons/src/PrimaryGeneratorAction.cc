#include "PrimaryGeneratorAction.hh"

#include "G4Event.hh"
#include "G4Neutron.hh"
#include "G4ParticleGun.hh"
#include "G4SystemOfUnits.hh"
#include "G4ThreeVector.hh"

namespace B1
{

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
  fParticleGun = new G4ParticleGun(1);

  fParticleGun->SetParticleDefinition(G4Neutron::Definition());

  fParticleGun->SetParticleEnergy(0.025 * eV);  

  fParticleGun->SetParticlePosition(G4ThreeVector(0., 0., -5 * cm));

  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0., 0., 1.));
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
  fParticleGun->GeneratePrimaryVertex(event);
}

}  // namespace B1
